<?php return array (
  'home' => 'App\\Http\\Livewire\\Home',
  'invitados.buscar-invitacion' => 'App\\Http\\Livewire\\Invitados\\BuscarInvitacion',
  'invitados.invitacion' => 'App\\Http\\Livewire\\Invitados\\Invitacion',
);