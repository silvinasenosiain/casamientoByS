<div>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">¡Hola <?php echo e($persona); ?>!</h5>
            <p class="card-text">Con inmensa alegría te invitamos a celebrar nuestro amor. 
            Te esperamos el sábado 24 de Septiembre a las 18:15 hs, en LaLola Multiespacio. ¿Venis/vienen?</p>
        </div>
        <?php if(count($invitados) > 0): ?>
        <span class = "text-center text-sm">Personas que fueron invitadas junto a vos</span>
        <?php endif; ?>
        <ul class="list-group list-group-flush">
            <?php $__empty_1 = true; $__currentLoopData = $invitados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class = "row mt-3 mb-3">
                <div class = "col-sm-6">
                    <li class="list-group-item" style = "border:none;"><?php echo e($invitado->personas->apellido.', '.$invitado->personas->nombre); ?></li>
                </div>
                <div class = "col-sm-6">
                    <?php if($invitado->estado == 'pendiente'): ?>
                    <button type="button" class="btn btn-outline-success" wire:click="invitacion_invitado('<?php echo e($invitado->id); ?>', 'aceptada')">Confirmar</button>
                    <button type="button" class="btn btn-outline-danger" wire:click="invitacion_invitado('<?php echo e($invitado->id); ?>', 'rechazada')">Rechazar</button>
                    <?php else: ?>
                    Invitación <?php echo e($invitado->estado); ?>

                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </ul>
        <div class="card-body">
            <?php if($estado == 'pendiente'): ?>
                <button type="button" class="btn btn-outline-success" wire:click="invitacion('<?php echo e($codigo); ?>', 'aceptada', 'uno')">Confirmar</button>
                <?php if(count($invitados) > 0): ?>
                <button type="button" class="btn btn-outline-success" wire:click="invitacion('<?php echo e($codigo); ?>', 'aceptada', 'todos')">Confirmar todo</button>
                <?php endif; ?>
                <button type="button" class="btn btn-outline-danger" wire:click="invitacion('<?php echo e($codigo); ?>', 'rechazada', 'uno')">Rechazar</button>
                <?php if(count($invitados) > 0): ?>
                <button type="button" class="btn btn-outline-danger" wire:click="invitacion('<?php echo e($codigo); ?>', 'rechazada', 'todos')">Rechazar todo</button>
                <?php endif; ?>
            <?php else: ?>
            Invitación <?php echo e($estado); ?>

            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\proyectos\boda\resources\views/livewire/invitados/invitacion.blade.php ENDPATH**/ ?>