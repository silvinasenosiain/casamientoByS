<div class="modal fade" id="m-detalle" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Detalle de invitación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="container">
                    <div class="row">
                        <table class="table">
                            <thead>
                                <tr>
                                    <td>Invitado</td>
                                    <td>Estado</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $invitados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($invitado->personas->apellido.', '.$invitado->personas->nombre); ?></td>
                                    <td>
                                        <?php if($invitado->estado == 'pendiente'): ?>
                                        Pendiente
                                        <?php elseif($invitado->estado == 'aceptada'): ?>
                                        Aceptada
                                        <?php else: ?>
                                        Rechazada
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\proyectos\boda\resources\views/modales/modal-detalle-invitacion.blade.php ENDPATH**/ ?>