

<?php $__env->startSection('content'); ?>
<style>
.input-box{
  position: relative;
}

.input-box i {
  position: absolute;
  right: 13px;
  top:12px;
  color:#ced4da;
}
</style>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-xl-12">
            <div class="container">
                <div class="row height d-flex justify-content-center align-items-center">
                    <div class="col-md-6">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('invitados.buscar-invitacion', [])->html();
} elseif ($_instance->childHasBeenRendered('6twZ8Bv')) {
    $componentId = $_instance->getRenderedChildComponentId('6twZ8Bv');
    $componentTag = $_instance->getRenderedChildComponentTagName('6twZ8Bv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6twZ8Bv');
} else {
    $response = \Livewire\Livewire::mount('invitados.buscar-invitacion', []);
    $html = $response->html();
    $_instance->logRenderedChild('6twZ8Bv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>               
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\boda\resources\views/invitados/buscar-invitacion.blade.php ENDPATH**/ ?>