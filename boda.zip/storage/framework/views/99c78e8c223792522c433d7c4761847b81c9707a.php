
<div 
    x-data="{ 
        buscar:<?php if ((object) ('buscar') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('buscar'->value()); ?>')<?php echo e('buscar'->hasModifier('defer') ? '.defer' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('buscar'); ?>')<?php endif; ?>,
        autoComplete:true, 
    }">
    <div class="container">
        <div class="row">
            <div class="">
                <p>Ingresá tu Apellido y Nombre para encontrarte en la lista</p>
            </div>
        </div>
    </div>
    <div class="input-box">
        <input wire:model="buscar" type="text" 
        @click="autoComplete=true"
        @click.away="autoComplete=false"
        @click.outside="autoComplete=false"
        @key.down.enter="autoComplete=true"
        class="form-control"
        style="background-color:white;">
        <i class="fa fa-search"></i>           
    </div> 
      
    <template x-if="autoComplete" x-transition.opacity> 
        <div class="shadow rounded px-3 pt-3 pb-0 orange lighten-5">
            <?php if(count($invitaciones) > 0): ?>
                <?php $__currentLoopData = $invitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="cursor: pointer;color:black;">
                    <a wire:click="seleccionarInvitacion('<?php echo e($invitacion->id); ?>')">
                        <?php echo e($invitacion->apellido.', '.$invitacion->nombre); ?>

                    </a>
                    <hr class = "mt-2 mb-2">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </template>       
</div>
<?php /**PATH C:\xampp\htdocs\proyectos\boda\resources\views/livewire/invitados/buscar-invitacion.blade.php ENDPATH**/ ?>