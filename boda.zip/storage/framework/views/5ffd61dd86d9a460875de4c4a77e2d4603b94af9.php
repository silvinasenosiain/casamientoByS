<div>
    <?php echo $__env->make('modales.modal-agregar-invitacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('modales.modal-agregar-invitado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('modales.modal-detalle-invitacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 p-0"></div>
            <div class="col-lg-4">
            <input type="text" wire:model="buscador" class="form-control" placeholder="Buscar...">
            </div>
            <div class="col-lg-4 float-end">
                <button data-bs-toggle="modal" data-bs-target="#m-agregar-invitacion" class="btn btn-outline-success" type="submit">Generar</button>
            </div>
        </div>
    </div>
    <table class="table">
        <thead>
            <tr>
                <th>Apellido</th>
                <th>Nombre</th>
                <th>Estado</th>
                <th>Invitados</th>
                <th></th>
            </tr>
        </thead> 
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $invitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($invitacion->apellido); ?></td>
                <td><?php echo e($invitacion->nombre); ?></td>
                <td>
                    <?php if($invitacion->estado == 'pendiente'): ?>
                    Pendiente
                    <?php elseif($invitacion->estado == 'aceptada'): ?>
                    Aceptada
                    <?php else: ?>
                    Rechazada
                    <?php endif; ?>
                </td>
                <td>
                <?php
                $invitados = App\Models\Invitacionesadicionals::where('invitacion_id', $invitacion->id)->count();
                ?>
                <?php echo e($invitados); ?>

                </td>
                <td>
                <?php
                $invitados
                ?>
                </td>
                <td>
                    <div class="btn-toolbar" role="toolbar">
                        <?php if($invitacion->estado == 'pendiente'): ?>
                        <div class="btn-group">
                            <button type="button" wire:click="agregar_invitado(<?php echo e($invitacion->id); ?>)" data-bs-toggle="modal" data-bs-target="#m-agregar-invitado" class="btn btn-outline-primary">
                                Agregar invitado
                            </button>  
                        </div>
                        <?php endif; ?>
                        <?php if($invitados > 0): ?>
                        <div class="btn-group" style = "margin-left:10px;">
                            <button type="button" wire:click="detalle_invitacion(<?php echo e($invitacion->id); ?>)" data-bs-toggle="modal" data-bs-target="#m-detalle" class="btn btn-outline-secondary">
                                Detalle
                            </button>  
                        </div>
                        <?php endif; ?>
                    </div>  
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5">No hay invitaciones..</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>  
    <?php echo e($invitaciones->links('vendor.livewire.simple-bootstrap')); ?> 
    Pendientes: <?php echo e($pendientes); ?><br>
    Aceptados: <?php echo e($aceptados); ?><br>
    Rechazados: <?php echo e($rechazados); ?> <br>
    Total: <?php echo e($total); ?>

</div>
<?php /**PATH C:\xampp\htdocs\proyectos\boda\resources\views/livewire/home.blade.php ENDPATH**/ ?>